# Casa Service — GitHub Pages (v2)
Aggiornamenti
- Logo ufficiale inserito (assets/logo.png)
- Slogan: "Che sia per la casa o per l'ufficio, Casa Service è con te."
- Rimossa la voce "biglietti da visita" dai servizi

Pubblicazione: Settings → Pages → Deploy from a branch → main → /root.
